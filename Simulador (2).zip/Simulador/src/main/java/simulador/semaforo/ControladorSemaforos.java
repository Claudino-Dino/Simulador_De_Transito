package simulador.semaforo;

public class ControladorSemaforos {
    public void aplicarControle(){
        System.out.println("Controle de semáforos aplicado.");
    }

}
