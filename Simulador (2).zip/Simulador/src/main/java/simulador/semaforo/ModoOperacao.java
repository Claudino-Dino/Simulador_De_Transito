package simulador.semaforo;

public enum ModoOperacao {
    CICLO_FIXO,
    TEMPO_ESPERA,
    CONSUMO
}
