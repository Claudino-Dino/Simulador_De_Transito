package simulador.cidade;

public enum Direcao {
    UNICA,
    DUPLA
}
