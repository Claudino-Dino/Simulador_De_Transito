package simulador.cidade;

public class Intersecao {
    public int id;
    public int qtdeSemaforos;
    public boolean temSemaforo;

    public Intersecao(int id, int qtdeSemaforos, boolean temSemaforo) {
        this.id = id;
        this.temSemaforo = temSemaforo;
        this.qtdeSemaforos = qtdeSemaforos;
    }
}
