package simulador.heuristica;

public class HeuristicaControle {
    public void aplicar(){
        System.out.println("Heurística de controle aplicada");
    }
}
