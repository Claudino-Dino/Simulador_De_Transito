package simulador.trafego;

import simulador.estruturas.FilaEncadeada;
import simulador.cidade.Intersecao;

public class Veiculo {
    private String id;
    private Intersecao origem;
    private Intersecao destino;
    private FilaEncadeada caminho;


    public Veiculo(String id, Intersecao origem) {
        this.id = id;
        this.origem = origem;
    }

    public void mover(Intersecao destino) {
        this.destino=destino;
    }

    public void calcularRota() {
        // Caminho
    }

    public boolean atingiuDestino(){
//        if ()
        return false;
    }

    public String id(){
        return this.id;
    }

    public Intersecao getOrigem() {
        return this.origem;
    }

    public Intersecao getDestino() {
        return this.destino;
    }

    public FilaEncadeada<Intersecao> getCaminho(){
        return this.caminho;
    }

}
