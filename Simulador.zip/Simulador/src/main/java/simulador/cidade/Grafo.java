package simulador.cidade;

import simulador.estruturas.ListaEncadeada;

public class Grafo {
    ListaEncadeada<Intersecao> intersecoes;
    ListaEncadeada<Rua> ruas;
    ListaEncadeada<Rua> obterArestasDe(Intersecao i) {
        ListaEncadeada<Rua> rua = new ListaEncadeada<>();

        for (Rua r: ruas) {
            if (r.noOrigem.equals(i)) {
                ruas.adicionar(r);
            }
        }
        return rua;
    }
}
