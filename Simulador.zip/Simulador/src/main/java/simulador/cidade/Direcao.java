package simulador.cidade;

public enum Direcao {
    MaoUnica("UNICA"),
    MaoDupla("DUPLA");

    public final String direcao;

    Direcao(String direcao){
        this.direcao=direcao;
    }

    public String getDirecao(){
        return direcao;
    }
}
