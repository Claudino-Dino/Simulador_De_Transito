package simulador;

public class Main {
    public static void main(String[] args) {
        Simulacao simulacao = new Simulacao();
        simulacao.iniciar();
    }
}
